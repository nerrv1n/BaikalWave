package com.example.baikalwave01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Main_menu_activity extends AppCompatActivity {

    BottomNavigationView navView;
    private static Fragment fragment = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        navView = findViewById(R.id.bottom_nav);

        if(MySqlConnection.order_is_null()==true)
        {
            System.out.println("rdftgyhukdfjnc");
        }


        if(MySqlConnection.order_is_null()==true) {
            getSupportFragmentManager().beginTransaction().replace(R.id.body_container, new OrderEmptyFragment()).commit();
        }
        else {
            getSupportFragmentManager().beginTransaction().replace(R.id.body_container, new OrderFragment()).commit();
        }

        navView.setSelectedItemId(R.id.nav_order);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                fragment = null;
                switch(item.getItemId()){

                    case R.id.nav_order:
                        if(MySqlConnection.order_is_null()==true) {
                            fragment = new OrderEmptyFragment();
                        }
                        else{
                            fragment=new OrderFragment();
                        }
                        break;
                    case R.id.profile_nav:
                        fragment = new profile_fragment();
                        break;
                    case R.id.nav_info:
                        fragment = new InfoFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.body_container, fragment).commit();
                return true;
            }
        });
    }
}