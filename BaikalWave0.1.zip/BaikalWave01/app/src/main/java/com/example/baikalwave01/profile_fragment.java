package com.example.baikalwave01;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

import java.sql.Driver;
import java.sql.SQLException;
import java.util.ArrayList;

public class profile_fragment extends Fragment {

    TextInputEditText fio, nts, ts, phone_num;
    Button save_button;
    private int login = MySqlConnection.getLogin();
    private Drv driver = null;
    private ArrayList drivers = MySqlConnection.drivers;

    private void searchDriver(){
        int size = drivers.size();
        for(int i=0;i<size;i++){
            Drv temp_driver = (Drv) drivers.get(i);
            int temp_login = Integer.parseInt(temp_driver.get_id());
            if(temp_login == login)
            {
                driver = temp_driver;
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inf = inflater.inflate(R.layout.fragment_profile_fragment, container, false);

        searchDriver();

        fio = inf.findViewById(R.id.fio);
        nts = inf.findViewById(R.id.nts);
        phone_num = inf.findViewById(R.id.phone_number);
        ts = inf.findViewById(R.id.ts);

        save_button = inf.findViewById(R.id.save_button);
        if(driver == null) {
            System.out.println("alyaulyu");
        }
        fio.setText(driver.getFio());
        nts.setText(driver.getNTS());
        phone_num.setText(driver.get_phone());
        ts.setText(driver.getTS());

        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp_fio = fio.getText().toString();
                System.out.println(temp_fio);
                String temp_nts = nts.getText().toString();
                String temp_num = phone_num.getText().toString();
                String temp_ts = ts.getText().toString();

                Thread connectionThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            MySqlConnection.getConnection();
                            MySqlConnection.update_driver(temp_fio,temp_nts,temp_num,temp_ts);
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                    }
                });
                connectionThread.start();
                AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                alertDialog.setTitle("Успешно!");
                alertDialog.setMessage("Данные сохранены!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Ок", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        });


        return inf;
    }
}