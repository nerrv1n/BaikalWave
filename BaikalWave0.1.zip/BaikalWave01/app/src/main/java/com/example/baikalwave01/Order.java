package com.example.baikalwave01;

public class Order {

    private String id;
    private String driver_id;
    private String price;
    private String type;
    private String num_of_people;
    private boolean guide;
    private String date;
    private String adress;
    private boolean food;

    public Order(String id, String driver_id, String price,String type, String num_of_people, boolean guide,
    String date, String adress, boolean food){
        this.id = id;
        this.driver_id = driver_id;
        this.price = price;
        this.type=type;
        this.num_of_people=num_of_people;
        this.guide=guide;
        this.date=date;
        this.adress=adress;
        this.food=food;
    }

    public int getDriverId(){
        int temp_id = Integer.parseInt(driver_id);
        return temp_id;
    }
    public String getPrice(){return this.price;}
    public String getType(){return this.type;}

    public String getNum_of_people() {
        return num_of_people;
    }

    public boolean isGuide() {
        return guide;
    }

    public String getDate() {
        return date;
    }

    public String getAdress() {
        return adress;
    }

    public boolean isFood() {
        return food;
    }

    public String getID(){
        return this.id;
    }
}
