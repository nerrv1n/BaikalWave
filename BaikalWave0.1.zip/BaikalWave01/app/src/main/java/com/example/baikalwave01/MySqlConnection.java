package com.example.baikalwave01;

import com.mysql.jdbc.MySQLConnection;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MySqlConnection {

    public static ArrayList drivers = new ArrayList();
    public static ArrayList orders = new ArrayList();
    private static Connection mysqlConnection;
    private static Statement stmt;
    private static ResultSet rs;
    public static int login;

    public static void update_driver(String fio, String nts, String phone_num, String ts) throws SQLException {

        //, nts = ? , phone = ? , ts = ?
        mysqlConnection = DriverManager.getConnection("jdbc:mysql://31.31.196.45:3306/u1671787_java", "u1671787_android", "eE3uM5hU0a" );
        String query = "update drivers set fio = ? where id = ?";
        PreparedStatement preparedStmt = mysqlConnection.prepareStatement(query);
        String log = "" + login;
        preparedStmt.setString   (1, fio);
        preparedStmt.setString(2, log);
        preparedStmt.executeUpdate();

        query = "update drivers set nts = ? where id = ?";
        preparedStmt = mysqlConnection.prepareStatement(query);
        preparedStmt.setString   (1, nts);
        preparedStmt.setString(2, log);
        preparedStmt.executeUpdate();

        query = "update drivers set phone = ? where id = ?";
        preparedStmt = mysqlConnection.prepareStatement(query);
        preparedStmt.setString   (1, phone_num);
        preparedStmt.setString(2, log);
        preparedStmt.executeUpdate();

        query = "update drivers set nts = ? where id = ?";
        preparedStmt = mysqlConnection.prepareStatement(query);
        preparedStmt.setString   (1, nts);
        preparedStmt.setString(2, log);
        preparedStmt.executeUpdate();

        query = "update drivers set ts = ? where id = ?";
        preparedStmt = mysqlConnection.prepareStatement(query);
        preparedStmt.setString   (1, ts);
        preparedStmt.setString(2, log);
        preparedStmt.executeUpdate();
    }

    public static boolean order_is_null(){

        int login = getLogin();
        int size = orders.size();

        for (int i=0;i<size;i++)
        {
            Order temp_order = (Order) orders.get(i);
            if (temp_order.getDriverId()==login)
            {
                System.out.println(temp_order.getID());
                return false;
            }
        }
        return true;
    }

    public static void setLogin(int log)
    {
        login=log;
    }

    public static int getLogin()
    {
        return login;
    }

    public static ArrayList getListDriver(){
        return drivers;
    }

    public static ArrayList getListOrders(){
        return orders;
    }

    public static void cancel_order() throws SQLException {
        mysqlConnection = DriverManager.getConnection("jdbc:mysql://31.31.196.45:3306/u1671787_java", "u1671787_android", "eE3uM5hU0a" );
        String query = "update orders set driver_id = ? where driver_id = ?";
        PreparedStatement preparedStmt = mysqlConnection.prepareStatement(query);
        String log = "" + login;
        preparedStmt.setString   (1, "0");
        preparedStmt.setString(2, log);

        System.out.println(preparedStmt);

        // execute the java preparedstatement
        preparedStmt.executeUpdate();
    }

    public static Connection getConnection() throws SQLException {

        String query = "select count(*) from drivers";
        try {

            Driver driver = (Driver) Class.forName("com.mysql.jdbc.Driver").newInstance();

            if (mysqlConnection==null) mysqlConnection = DriverManager.getConnection("jdbc:mysql://31.31.196.45:3306/u1671787_java", "u1671787_android", "eE3uM5hU0a" );
            stmt = mysqlConnection.createStatement();
            rs = stmt.executeQuery(query);

            System.out.println("нет");

            while(rs.next()){
                int count= rs.getInt(1);
                System.out.println("Total number of drivers in the table : " + count);
            }

            query = "select id, password, fio, nts, phone, ts from drivers";

            rs = stmt.executeQuery(query);

            while (rs.next())
            {
                String id = rs.getString(1);
                String pass = rs.getString(2);
                String fio = rs.getString(3);
                String NTS = rs.getString(4);
                String phone = rs.getString(5);
                String TS = rs.getString(6);

                Drv drvr = new Drv(id, pass, fio, NTS, phone, TS);
                drivers.add(drvr);
            }

            query = "select id, driver_id, price, type, num_of_people, guide, date, adress, food from orders";

            rs = stmt.executeQuery(query);

            while(rs.next())
            {
                String id = rs.getString(1);
                String driver_id = rs.getString(2);
                String price = rs.getString(3);
                String type = rs.getString(4);
                String num_of_people = rs.getString(5);
                boolean guide = rs.getBoolean(6);
                String date = rs.getString(7);
                String adress = rs.getString(8);
                boolean food = rs.getBoolean(9);

                Order order = new Order(id,driver_id,price,type,num_of_people,guide,date,adress,food);
                orders.add(order);
            }

            query="SET NAMES 'utf8'";
            stmt.execute(query);
            query="SET CHARACTER SET 'utf8'";
            stmt.execute(query);
            query="SET SESSION collation_connection = 'utf8_general_ci'";
            stmt.execute(query);



            return mysqlConnection;

        } catch (SQLException| ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            ex.printStackTrace();
            Logger.getLogger(MySQLConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }


}