package com.example.baikalwave01;

import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderFragment extends Fragment {

    private TextView date, price, type, adress, num_of_people;
    private ImageView food, guide, map_hoboi, map_transfer, map_south;

    Order main_order;
    ArrayList orders;

    private void selectOrder(){

        int login = MySqlConnection.getLogin();
        System.out.println(login);
        int size = orders.size();

        for (int i=0;i<size;i++)
        {
            Order temp_order = (Order) orders.get(i);
            if (temp_order.getDriverId()==login)
            {
                main_order=temp_order;
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        orders = MySqlConnection.getListOrders();
        selectOrder();

        View inf = inflater.inflate(R.layout.fragment_order, container, false);

        Button cancel_button = inf.findViewById(R.id.cancel_button);
        date = inf.findViewById(R.id.date);
        price = inf.findViewById(R.id.price);
        type = inf.findViewById(R.id.type);
        adress = inf.findViewById(R.id.adress);
        num_of_people = inf.findViewById(R.id.num_people);
        food = inf.findViewById(R.id.food);
        guide = inf.findViewById(R.id.guide);
        map_hoboi = inf.findViewById(R.id.map_hoboi);
        map_south = inf.findViewById(R.id.map_south);
        map_transfer = inf.findViewById(R.id.map_transfer);


        date.setText(main_order.getDate());
        price.setText(main_order.getPrice());
        type.setText(main_order.getType());
        adress.setText(main_order.getAdress());
        num_of_people.setText(main_order.getNum_of_people());
        if(main_order.isFood()==false)
        {
            food.setVisibility(View.INVISIBLE);
        }
        System.out.println(main_order.getType());
        if(main_order.isGuide()==false)
        {
            guide.setVisibility(View.INVISIBLE);
        }
        if(main_order.getType().equals("трансфер"))
        {
            map_south.setVisibility(View.INVISIBLE);
            map_hoboi.setVisibility(View.INVISIBLE);
        }
        if(main_order.getType().equals("юг"))
        {
            map_hoboi.setVisibility(View.INVISIBLE);
            map_transfer.setVisibility(View.INVISIBLE);
        }
        if(main_order.getType().equals("хобой"))
        {
            map_transfer.setVisibility(View.INVISIBLE);
            map_south.setVisibility(View.INVISIBLE);
        }

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                alertDialog.setTitle("Внимание!");
                alertDialog.setMessage("Вы уверены, что хотите отказаться от заказа?");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Thread connectionThread = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    MySqlConnection.getConnection();
                                    MySqlConnection.cancel_order();
                                } catch (SQLException throwables) {
                                    throwables.printStackTrace();
                                }
                            }
                        });
                        connectionThread.start();

                        alertDialog.dismiss();
                    }
                });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Нет", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        });
        return inf;
    }
}