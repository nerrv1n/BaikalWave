package com.example.baikalwave01;

public class Drv {

    private String id;
    private String pass;
    private String fio;
    private String NTS;
    private String phone;
    private String TS;

    public Drv(String id, String pass, String fio, String NTS, String phone, String TS) {
        this.id=id;
        this.pass=pass;
        this.fio=fio;
        this.NTS = NTS;
        this.phone=phone;
        this.TS=TS;
    }

    public String get_phone(){return this.phone;}
    public String get_pass(){return this.pass;}
    public String get_id(){return this.id;}

    public String getId() {
        return id;
    }

    public String getFio() {
        return fio;
    }

    public String getNTS() {
        return NTS;
    }
    public String getTS(){return TS;}
}
