package com.example.baikalwave01;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.sql.SQLException;
import java.util.ArrayList;

public class LoginMenu extends AppCompatActivity {

    EditText usernameField, passwordField;
    Button buttonSignUp, phone_button;

    private ArrayList drivers = new ArrayList();

    private int Login;
    private int Password;

    static int PERMISSION_CODE = 100;
    private static String phone_number = "89148781043";

    private int comparePassDrivers(int id, int pass) {
        Drv drv;
        int size = drivers.size();
        int detector = 0;

        for (int i = 0; i < size; i++) {
            drv = (Drv) drivers.get(i);
            int login = Integer.parseInt(drv.get_id());
            int password = Integer.parseInt(drv.get_pass());
            if (id == login && pass == password) {
                detector = 1;
            }
        }
        return detector;
    }

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.drivers=MySqlConnection.getListDriver();

        if (ContextCompat.checkSelfPermission(LoginMenu.this,Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){

            ActivityCompat.requestPermissions(LoginMenu.this,new String[]{Manifest.permission.CALL_PHONE},PERMISSION_CODE);

        }

        usernameField = findViewById(R.id.id);
        passwordField = findViewById(R.id.password);
        buttonSignUp = findViewById(R.id.button_in);
        phone_button = findViewById(R.id.phone_button);

        Thread connectionThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    MySqlConnection.getConnection();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                    }
                });
            }
        });
        connectionThread.start();

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Password = Integer.parseInt(passwordField.getText().toString());
                Login = Integer.parseInt(usernameField.getText().toString());

                if(comparePassDrivers(Login,Password)==1)
                {
                    MySqlConnection.setLogin(Login);
                    Intent intent = new Intent(LoginMenu.this, Main_menu_activity.class);
                    startActivity(intent);
                }
                else {
                    AlertDialog alertDialog = new AlertDialog.Builder(LoginMenu.this).create();
                    alertDialog.setTitle("Ошибка!");
                    alertDialog.setMessage("Неврный логин или пароль!");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Ок", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            alertDialog.dismiss();
                            usernameField.setText("");
                            passwordField.setText("");
                        }
                    });
                    alertDialog.show();
                }
            }
        });

        phone_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+phone_number));
                startActivity(i);
            }
        });
    }
}